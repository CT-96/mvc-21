<?php

namespace Src;

class Model
{
    private $pdo;
    
    public function _construct(PDO $pdo = null)
    {
        $this->pdo = $pdo;
    }
    public function get()
    {
        return [
            'name'=>'carlos'
        ];
    }
}