<?php

namespace App\Models;

use Src\Model;

class User extends model
{
    
}