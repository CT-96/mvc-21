<?php

namespace App\Controllers;
use Src\Controller;
use  App\Models\User;
use App\Models\Product;

class UsersController extends Controller
{ 
 /* public function __construct(User $model, product $product)
    {
      var_dump(get_class($model));
      var_dump(get_class($product));
      $this->model = $model;
    }*/

   public function index(User $model)
   {
      $user = $model->get();
      $this->render($user); //(['name' => 'virginia']); //,'users/index');
   } 
   public function create()
   {
      return 'cadastro de usuarios';
   } 
   
}