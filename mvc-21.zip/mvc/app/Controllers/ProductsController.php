<?php

namespace App\Controllers;
use Src\Controller;
use App\Models\Product;

class ProductsController extends Controller
{ 
  public function __construct(Product $model)
    {
      var_dump(get_class($model));
      $this->model = $model;
    }

   public function index()
   {
      $this->render();
   } 
   
}