<?php

$router = new Src\Router;
$router['/'] = [
    'class' => 'App\controllers\UsersController',
    //'controller' => App\controllers\UsersControlle::class,
    'action' => 'index'
];
$router['/registro'] = [
    'class' => 'App\controllers\UsersController',
    //'controller' => App\controllers\UsersControlle::class,
    'action' => 'create'
];
$router['/products'] = [
    'class' => 'App\controllers\ProductsController',
    //'controller' => App\controllers\UsersControlle::class,
    'action' => 'index'
];
return $router;

