<?php

$resolver = new Src\Resolver;

$resolver['PDO'] = function($r)
{
    return new PDO('mysql:host=localhost,dbname=php-pd','root', null, [PDO::ATTR_ERRMODE => PDO::ATTR_ERRMODE_EXCEPTION]);
};

return $resolver;